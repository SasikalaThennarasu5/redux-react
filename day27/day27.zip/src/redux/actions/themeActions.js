export const toggleTheme = () => ({ type: 'TOGGLE_THEME' });
