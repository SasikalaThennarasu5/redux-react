const Sidebar = () => <div style={{ width: '200px', background: '#eee', padding: '10px' }}>Sidebar</div>;
export default Sidebar;
