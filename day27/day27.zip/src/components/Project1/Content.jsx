const Content = () => <div style={{ padding: '10px' }}>Main Content Area</div>;
export default Content;
