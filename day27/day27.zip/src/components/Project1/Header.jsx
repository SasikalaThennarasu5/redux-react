const Header = () => <div style={{ background: '#ccc', padding: '10px' }}>Header</div>;
export default Header;
