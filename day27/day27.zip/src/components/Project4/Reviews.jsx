const Reviews = () => (
  <div>
    <h4>Customer Reviews</h4>
    <ul>
      <li>⭐⭐⭐⭐ - Great product!</li>
      <li>⭐⭐⭐ - Comfortable but sizing runs small.</li>
    </ul>
  </div>
);

export default Reviews;
