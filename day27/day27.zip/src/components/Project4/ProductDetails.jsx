const ProductDetails = () => (
  <div>
    <h4>Product Name: Awesome Shoes</h4>
    <p>Description: Lightweight, stylish, and affordable.</p>
    <p>Price: $49.99</p>
  </div>
);

export default ProductDetails;
