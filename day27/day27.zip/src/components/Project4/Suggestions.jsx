const Suggestions = () => (
  <div>
    <h4>You Might Also Like</h4>
    <ul>
      <li>Cool Sneakers</li>
      <li>Running Shoes</li>
    </ul>
  </div>
);

export default Suggestions;
