const CurrentWeather = () => (
  <div>
    <h4>Current Weather</h4>
    <p>🌞 28°C, Sunny</p>
  </div>
);

export default CurrentWeather;
