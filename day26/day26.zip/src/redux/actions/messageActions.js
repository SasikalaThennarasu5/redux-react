// --- redux/actions/messageActions.js ---
export const setMessage = (msg) => ({ type: 'SET_MESSAGE', payload: msg });